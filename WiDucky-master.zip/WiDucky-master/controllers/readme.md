These are three sources for WiDucky controller applications in C#, Android and Python
(Please note these are designed for US and UK keyboards only.)
Refer to the Script Syntax documentation for scripting details and examples.
